package tmp;

public class denial {
}
